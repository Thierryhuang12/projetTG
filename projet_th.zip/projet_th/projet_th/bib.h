#ifndef PROJET_TH_BIB_H
#define PROJET_TH_BIB_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define MAX_SOMMETS 100
#define INFINI 9999999

typedef struct {
    char nom[20];
    double population;
    double coefficientCroissance;
} Sommet;

int graphe[MAX_SOMMETS][MAX_SOMMETS]={0};
Sommet sommets[MAX_SOMMETS];
int nombreDeSommets = 0;

int trouverIndexSommet(char *nom);
void ajouterSommetDetail(char *nom, int population, float croissance);
void ajouterArc(char *origine, char *destination, int poids);
void genererDotFile(const char *nomFichier);

#endif // PROJET_TH_BIB_H
