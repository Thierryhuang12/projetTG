#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "bib.h"
#include <windows.h>


void color(int texte, int fond) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, (fond << 4) | texte);
}
int trouverIndexSommet(char *nom) {
    for (int i = 0; i < nombreDeSommets; i++) {
        if (strcmp(sommets[i].nom, nom) == 0) {
            return i;
        }
    }
    return -1;
}

void ajouterSommet(char *nom) {
    strcpy(sommets[nombreDeSommets++].nom, nom);
}

void ajouterArc(char *origine, char *destination, int poids) {
    int u = trouverIndexSommet(origine);
    int v = trouverIndexSommet(destination);
    if (u == -1) {
        ajouterSommet(origine);
        u = nombreDeSommets - 1;
    }
    if (v == -1) {
        ajouterSommet(destination);
        v = nombreDeSommets - 1;
    }
    graphe[u][v] = poids;
}
void afficherPredSucc(int sommet) {
    printf("\nRelations pour %s :\n", sommets[sommet].nom);

    // Successeurs
    printf("Successeurs : ");
    int hasSuccesseurs = 0;
    for (int i = 0; i < nombreDeSommets; i++) {
        if (graphe[sommet][i] > 0) {
            printf("%s (poids: %d) ", sommets[i].nom, graphe[sommet][i]);
            hasSuccesseurs = 1;
        }
    }
    if (!hasSuccesseurs) printf("Aucun");
    printf("\n");

    // Prédécesseurs
    printf("Predecesseurs : ");
    int hasPredecesseurs = 0;
    for (int i = 0; i < nombreDeSommets; i++) {
        if (graphe[i][sommet] > 0) {
            printf("%s (poids: %d) ", sommets[i].nom, graphe[i][sommet]);
            hasPredecesseurs = 1;
        }
    }
    if (!hasPredecesseurs) printf("Aucun");
    printf("\n");
}

void dijkstra(int source, int destination) {
    int distance[MAX_SOMMETS];
    int precedent[MAX_SOMMETS];
    int visite[MAX_SOMMETS] = {0};

    for (int i = 0; i < nombreDeSommets; i++) {
        distance[i] = INFINI;
        precedent[i] = -1;
    }
    distance[source] = 0;

    for (int i = 0; i < nombreDeSommets - 1; i++) {
        int minDistance = INFINI, u = -1;

        for (int j = 0; j < nombreDeSommets; j++) {
            if (!visite[j] && distance[j] < minDistance) {
                minDistance = distance[j];
                u = j;
            }
        }

        if (u == -1) break;
        visite[u] = 1;

        for (int v = 0; v < nombreDeSommets; v++) {
            if (!visite[v] && graphe[u][v] && distance[u] != INFINI && distance[u] + graphe[u][v] < distance[v]) {
                distance[v] = distance[u] + graphe[u][v];
                precedent[v] = u;
            }
        }
    }

    if (distance[destination] == INFINI) {
        printf("Aucun chemin trouve de %s a %s.\n", sommets[source].nom, sommets[destination].nom);
        return;
    }

    printf("Chemin le plus court de %s a %s avec une distance de %d :\n", sommets[source].nom, sommets[destination].nom, distance[destination]);

    int chemin[MAX_SOMMETS], compte = 0;
    for (int v = destination; v != -1; v = precedent[v]) {
        chemin[compte++] = v;
    }

    for (int i = compte - 1; i >= 0; i--) {
        printf("%s", sommets[chemin[i]].nom);
        if (i > 0) printf(" -> ");
    }
    printf("\n");
}

void afficherGraphe() {
    printf("\nGraphe entier :\n");
    for (int i = 0; i < nombreDeSommets; i++) {
        printf("%s : ", sommets[i].nom);
        int hasRelations = 0;
        for (int j = 0; j < nombreDeSommets; j++) {
            if (graphe[i][j] > 0) {
                printf("-> %s (poids: %d) ", sommets[j].nom, graphe[i][j]);
                hasRelations = 1;
            }
        }
        if (!hasRelations) printf("Aucune relation");
        printf("\n");
    }
}
void calculerDegre(int sommet) {
    int degreInterieur = 0, degreExterieur = 0;

    for (int i = 0; i < nombreDeSommets; i++) {
        if (graphe[i][sommet] > 0) degreInterieur++;
        if (graphe[sommet][i] > 0) degreExterieur++;
    }

    printf("Sommet %s : Degre interieur = %d, Degre exterieur = %d\n",
           sommets[sommet].nom, degreInterieur, degreExterieur);
}

// Calcul de la centralité d'intermédiarité -> sommets
void calculerCentraliteIntermediaire() {
    int centralite[MAX_SOMMETS] = {0};

    for (int source = 0; source < nombreDeSommets; source++) {
        for (int destination = 0; destination < nombreDeSommets; destination++) {
            if (source != destination) {
                //algo de Dijkstra pour trouve le plus petit
                int distance[MAX_SOMMETS], precedent[MAX_SOMMETS], visite[MAX_SOMMETS] = {0};

                for (int i = 0; i < nombreDeSommets; i++) {
                    distance[i] = INFINI;
                    precedent[i] = -1;
                }
                distance[source] = 0;

                for (int i = 0; i < nombreDeSommets - 1; i++) {
                    int minDistance = INFINI, u = -1;

                    for (int j = 0; j < nombreDeSommets; j++) {
                        if (!visite[j] && distance[j] < minDistance) {
                            minDistance = distance[j];
                            u = j;
                        }
                    }

                    if (u == -1) break;
                    visite[u] = 1;

                    for (int v = 0; v < nombreDeSommets; v++) {
                        if (!visite[v] && graphe[u][v] > 0 && distance[u] != INFINI &&
                            distance[u] + graphe[u][v] < distance[v]) {
                            distance[v] = distance[u] + graphe[u][v];
                            precedent[v] = u;
                        }
                    }
                }


                for (int v = destination; v != -1; v = precedent[v]) {
                    if (v != source && v != destination) {
                        centralite[v]++;
                    }
                }
            }
        }
    }

    printf("\nCentralite d'intermediarite :\n");
    for (int i = 0; i < nombreDeSommets; i++) {
        printf("Sommet %s : %d\n", sommets[i].nom, centralite[i]);
    }
}

void dfs(int sommet, int visite[], int niveaux[], int graphe[MAX_SOMMETS][MAX_SOMMETS], int nombreDeSommets) {
    if (visite[sommet]) return;
    visite[sommet] = 1;

    int maxNiveau = 0;
    for (int i = 0; i < nombreDeSommets; i++) {
        if (graphe[sommet][i] > 0) {
            dfs(i, visite, niveaux, graphe, nombreDeSommets);
            if (niveaux[i] > maxNiveau) {
                maxNiveau = niveaux[i];
            }
        }
    }

    niveaux[sommet] = maxNiveau + 1;
}


void calculerNiveauxTrophiques(int niveaux[]) {
    int visite[MAX_SOMMETS] = {0};




    for (int i = 0; i < nombreDeSommets; i++) {
        if (!visite[i]) {
            dfs(i, visite, niveaux, graphe, nombreDeSommets);
        }
    }


    int maxTrophique = 0;
    for (int i = 0; i < nombreDeSommets; i++) {
        if (niveaux[i] > maxTrophique) {
            maxTrophique = niveaux[i];
        }
    }

    for (int i = 0; i < nombreDeSommets; i++) {
        niveaux[i] = 4 - niveaux[i];
    }
}

void genererDotFile(const char *nomFichier) {
    FILE *file = fopen(nomFichier, "w");
    if (!file) {
        printf("Erreur d'ouverture du fichier DOT.\n");
        return;
    }

    fprintf(file, "digraph graphe {\n");

    // Ajout des arcs
    for (int i = 0; i < nombreDeSommets; i++) {
        for (int j = 0; j < nombreDeSommets; j++) {
            if (graphe[i][j] > 0) {
                fprintf(file, "    %s -> %s [label=\"%d\"];\n",
                        sommets[i].nom, sommets[j].nom, graphe[i][j]);
            }
        }
    }

    // Ajout des sommets isolés
    for (int i = 0; i < nombreDeSommets; i++) {
        int hasRelations = 0;
        for (int j = 0; j < nombreDeSommets; j++) {
            if (graphe[i][j] > 0 || graphe[j][i] > 0) {
                hasRelations = 1;
                break;
            }
        }
        if (!hasRelations) {
            fprintf(file, "    %s;\n", sommets[i].nom);
        }
    }

    fprintf(file, "}\n");
    fclose(file);
    printf("Fichier DOT genere : %s\n", nomFichier);
}

void ajouterSommetInteractif(const char *fichierDot) {
    char nom[20];
    printf("Entrez le nom du sommet a ajouter : ");
    scanf("%s", nom);

    // Verifie si le sommet existe deja
    if (trouverIndexSommet(nom) != -1) {
        printf("Erreur : Le sommet '%s' existe deja.\n", nom);
        return;
    }

    // Ajoute le sommet
    ajouterSommet(nom);
    printf("Sommet '%s' ajoute avec succes.\n", nom);

    // Ajouter des arcs sortants (ce que le sommet "mange")
    char choix;
    char destination[20];
    int poids;

    printf("Voulez-vous ajouter des arcs sortants (ce que '%s' mange) ? (o/n) : ", nom);
    scanf(" %c", &choix);
    while (choix == 'o' || choix == 'O') {
        printf("Entrez le nom du sommet de destination (ce que '%s' mange) : ", nom);
        scanf("%s", destination);

        if (trouverIndexSommet(destination) == -1) {
            printf("Le sommet de destination '%s' n'existe pas. Ajoutez-le d'abord.\n", destination);
            continue;
        }

        printf("Entrez le poids de l'arc : ");
        scanf("%d", &poids);

        ajouterArc(nom, destination, poids);
        printf("Arc ajoute : %s -> %s (poids : %d)\n", nom, destination, poids);

        printf("Voulez-vous ajouter un autre arc sortant pour '%s' ? (o/n) : ", nom);
        scanf(" %c", &choix);
    }

    // Ajouter des arcs entrants (ce qui mange le sommet)
    printf("Voulez-vous ajouter des arcs entrants (ce qui mange '%s') ? (o/n) : ", nom);
    scanf(" %c", &choix);
    while (choix == 'o' || choix == 'O') {
        printf("Entrez le nom du sommet source (ce qui mange '%s') : ", nom);
        scanf("%s", destination);

        if (trouverIndexSommet(destination) == -1) {
            printf("Le sommet source '%s' n'existe pas. Ajoutez-le d'abord.\n", destination);
            continue;
        }

        printf("Entrez le poids de l'arc : ");
        scanf("%d", &poids);

        ajouterArc(destination, nom, poids);
        printf("Arc ajoute : %s -> %s (poids : %d)\n", destination, nom, poids);

        printf("Voulez-vous ajouter un autre arc entrant pour '%s' ? (o/n) : ", nom);
        scanf(" %c", &choix);
    }

    // Met a jour le fichier DOT temporaire
    genererDotFile(fichierDot);
    printf("Le fichier DOT (%s) a ete mis a jour.\n", fichierDot);
}

void supprimerSommet(char *nom) {
    int index = trouverIndexSommet(nom);
    if (index == -1) {
        printf("Erreur : Le sommet '%s' n'existe pas.\n", nom);
        return;
    }

    // Supprime les arcs entrants et sortants
    for (int i = 0; i < nombreDeSommets; i++) {
        graphe[index][i] = 0; // Supprime les arcs sortants
        graphe[i][index] = 0; // Supprime les arcs entrants
    }

    // Décale les sommets pour supprimer le sommet donné
    for (int i = index; i < nombreDeSommets - 1; i++) {
        sommets[i] = sommets[i + 1]; // Décale les noms des sommets
        for (int j = 0; j < nombreDeSommets; j++) {
            graphe[i][j] = graphe[i + 1][j]; // Décale la ligne de la matrice
            graphe[j][i] = graphe[j][i + 1]; // Décale la colonne de la matrice
        }
    }

    nombreDeSommets--; // Met à jour le nombre de sommets
    printf("Le sommet '%s' a ete supprime avec succes.\n", nom);
}

void ajouterArcInteractif() {
    char origine[20], destination[20];
    int poids;

    // Demander à l'utilisateur les informations de l'arc
    printf("Entrez le nom du sommet origine (celui qui mange) : ");
    scanf("%s", origine);

    printf("Entrez le nom du sommet destination (celui qui est mange) : ");
    scanf("%s", destination);

    // Vérifie si les deux sommets existent
    int indexOrigine = trouverIndexSommet(origine);
    int indexDestination = trouverIndexSommet(destination);

    if (indexOrigine == -1) {
        printf("Erreur : Le sommet '%s' n'existe pas.\n", origine);
        return;
    }

    if (indexDestination == -1) {
        printf("Erreur : Le sommet '%s' n'existe pas.\n", destination);
        return;
    }

    // Vérifie si un arc existe déjà entre les deux sommets
    if (graphe[indexOrigine][indexDestination] > 0) {
        printf("Erreur : Un arc existe deja entre '%s' et '%s'.\n", origine, destination);
        return;
    }

    // Demander le poids de l'arc
    printf("Entrez le poids de l'arc : ");
    scanf("%d", &poids);

    // Ajoute l'arc
    ajouterArc(origine, destination, poids);
    printf("Arc ajoute : %s -> %s (poids : %d)\n", origine, destination, poids);
}


void supprimerArc() {
    char origine[20], destination[20];
    int poids;

    // Demander à l'utilisateur les informations de l'arc
    printf("Entrez le nom du sommet origine (celui qui mange) : ");
    scanf("%s", origine);

    printf("Entrez le nom du sommet destination (celui qui est mange) : ");
    scanf("%s", destination);

    printf("Entrez le poids de l'arc : ");
    scanf("%d", &poids);

    // Vérifie si les deux sommets existent
    int indexOrigine = trouverIndexSommet(origine);
    int indexDestination = trouverIndexSommet(destination);

    if (indexOrigine == -1) {
        printf("Erreur : Le sommet '%s' n'existe pas.\n", origine);
        return;
    }

    if (indexDestination == -1) {
        printf("Erreur : Le sommet '%s' n'existe pas.\n", destination);
        return;
    }

    // Vérifie si l'arc existe avec le poids donné
    if (graphe[indexOrigine][indexDestination] != poids) {
        printf("Erreur : Arc inexistant entre '%s' et '%s' avec le poids %d.\n", origine, destination, poids);
        return;
    }

    // Supprime l'arc
    graphe[indexOrigine][indexDestination] = 0;
    printf("Arc supprime : %s -> %s (poids : %d)\n", origine, destination, poids);
}


int main() {
    int continuer = 1;
    char choix2[100];
    char fichierDot[50];
    do {
        color(1, 0);
        printf("\n***********************************************************\n");
        printf("\nVeuillez choisir le fichier graphe que vous voulez ouvrir\n\n");

        color(4, 0);
        printf("\nchoix 1 : la savane  -> taper : graphe.txt\n");
        color(2, 0);
        printf("\nchoix 2 : la maison  -> taper : graphe2.txt\n");
        color(6, 0);
        printf("\nchoix 3 : la foret  -> taper : graphe3.txt\n");
        color(7, 0);
        printf("\nchoix :");
        scanf("%s", choix2);
        FILE *fichier = fopen(choix2, "r");
        if (!fichier) {
            printf("Erreur d'ouverture du fichier.\n");
            return 1;
        }

        if (strcmp(choix2, "graphe.txt") == 0) {
            strcpy(fichierDot, "graphe.dot");
        } else if (strcmp(choix2, "graphe2.txt") == 0) {
            strcpy(fichierDot, "graphe2.dot");
        } else if (strcmp(choix2, "graphe3.txt") == 0) {
            strcpy(fichierDot, "graphe3.dot");
        } else {
            printf("Fichier invalide.\n");
            return 1;
        }

        printf("Fichier DOT selectionne: %s\n", fichierDot);

        int niveaux[MAX_SOMMETS];
        char origine[20], destination[20];
        int poids;

        while (fscanf(fichier, "%s %s %d", origine, destination, &poids) == 3) {
            ajouterArc(origine, destination, poids);
        }

        fclose(fichier);

        while (1) {
            printf("\n\n ************************************\n\n");
            printf("\nMenu :\n");
            printf("1. Trouver le chemin le plus court\n");
            printf("2. Afficher predecesseurs et successeurs\n");
            printf("3. Afficher tout le graphe\n");
            printf("4. centralite d'intermediarite\n");
            printf("5. degre sommets\n");
            printf("6. Calcul des niveaux trophiques\n");
            printf("7. Generer un fichier DOT\n");
            printf("8. changer de fichier \n");
            printf("9. Ajouter un sommet\n");
            printf("10. Supprimer un sommet\n");
            printf("11. Ajouter un arc entre deux sommets existants\n");
            printf("12. Supprimer un arc existant\n");
            printf("13. Quitter\n");

            printf("\n\n ************************************\n\n");
            printf("Votre choix : ");
            int choix;
            scanf("%d", &choix);


            if (choix == 1) {
                printf("\n\n ************************************\n\n");
                printf("Entrez le sommet de depart : ");
                scanf("%s", origine);
                printf("Entrez le sommet d'arrivee : ");
                scanf("%s", destination);

                int src = trouverIndexSommet(origine);
                int dest = trouverIndexSommet(destination);

                if (src == -1 || dest == -1) {
                    printf("Sommets invalides.\n");
                    continue;
                }

                dijkstra(src, dest);
            } else if (choix == 2) {
                printf("\n\n ************************************\n\n");
                printf("Entrez le sommet a explorer : ");
                scanf("%s", origine);

                int sommet = trouverIndexSommet(origine);
                if (sommet == -1) {
                    printf("Sommet invalide.\n");
                    continue;
                }

                afficherPredSucc(sommet);
            } else if (choix == 3) {
                printf("\n\n ************************************\n\n");
                afficherGraphe();
            }
            if (choix == 5) {
                printf("\n\n ************************************\n\n");
                printf("Entrez le nom du sommet : ");
                scanf("%s", origine);
                int sommet = trouverIndexSommet(origine);
                if (sommet == -1) {
                    printf("Sommet invalide.\n");
                    continue;
                }
                calculerDegre(sommet);
            } else if (choix == 4) {
                printf("\n\n ************************************\n\n");
                calculerCentraliteIntermediaire();

            } else if (choix == 6) {
                printf("\n\n ************************************\n\n");
                // Calcul et affichage des niveaux trophiques
                calculerNiveauxTrophiques(niveaux);
                printf("\nNiveaux trophiques :\n");
                for (int i = 0; i < nombreDeSommets; i++) {
                    printf("Sommet %s : Niveau %d\n", sommets[i].nom, niveaux[i]);
                }
            } else if (choix == 7) {
                printf("\n\n ************************************\n\n");
                char nomFichier[50];
                printf("Entrez le nom du fichier DOT a generer (par ex. graphe.dot) : ");
                scanf("%s", nomFichier);

                genererDotFile(nomFichier);
            } else if (choix == 8) {
                printf("\nRetour au menu de selection de fichier.\n");
                break; // Retour au menu de sélection de fichier
            } else if (choix == 9) { // Ajouter un sommet
                ajouterSommetInteractif(fichierDot);
                genererDotFile(fichierDot);
                printf("Fichier DOT mis a jour : %s\n", fichierDot);
            }else if (choix == 10) {
                printf("\n\n ************************************\n\n");
                printf("Entrez le nom du sommet a supprimer : ");
                char nom[20];
                scanf("%s", nom);

                supprimerSommet(nom);

                // Met à jour le fichier DOT pour refléter les modifications
                genererDotFile(fichierDot);
                printf("Le fichier DOT (%s) a ete mis a jour.\n", fichierDot);
            }else if (choix == 11) {
                printf("\n\n ************************************\n\n");
                ajouterArcInteractif();

                // Met à jour le fichier DOT pour refléter les modifications
                genererDotFile(fichierDot);
                printf("Le fichier DOT (%s) a ete mis a jour.\n", fichierDot);
            }else if (choix == 12) {
                printf("\n\n ************************************\n\n");
                supprimerArc();

                // Met à jour le fichier DOT pour refléter les modifications
                genererDotFile(fichierDot);
                printf("Le fichier DOT (%s) a ete mis a jour.\n", fichierDot);
            }else if (choix == 13) {
                continuer = 0; // Quitte le programme
                break;
            }else {
                // printf("Choix invalide.\n");
            }
        }
    }while(continuer);

    return 0;
}